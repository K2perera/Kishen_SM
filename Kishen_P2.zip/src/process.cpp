#include <unistd.h>
#include <cctype>
#include <sstream>
#include <string>
#include <vector>

#include "process.h" 
#include "linux_parser.h"  

using std::string; 
using std::to_string; 
using std::vector; 
//constructor 
Process::Process(int P_ID) {
    p_id = P_ID;   
    cpu_ = CpuUtilization(); 
    up_time = LinuxParser::UpTime(P_ID); 
    ram = LinuxParser::Ram(P_ID); 
    user = LinuxParser::User(P_ID); 
    command = LinuxParser::Command(P_ID); 
}

// TODO: Return this process's ID
int Process::Pid() { return p_id ; }

// TODO: Return this process's CPU utilization
float Process::CpuUtilization() { 
    string line;  
    std::string PID = to_string(p_id); 
    std::ifstream file(LinuxParser::kProcDirectory + PID +LinuxParser::kStatFilename);  
    std::getline(file,line);   
    std::istringstream linestream(line); 
    std::vector<std::string> results(std::istream_iterator<std::string>{linestream}, std::istream_iterator<std::string>());
    float u_t,s_t,c_t,cstime,start,total,seconds; 
    u_t = stof(results[13]); 
    s_t = stof(results[14]); 
    c_t = stof(results[15]); 
    cstime = stof(results[16]); 
    start = stof(results[21]); 
    total = u_t + s_t + c_t + cstime; 
    seconds = UpTime() - start / sysconf(_SC_CLK_TCK); 
    return total / sysconf(_SC_CLK_TCK) / seconds;  
}

// TODO: Return the command that generated this process
string Process::Command() { 
  return LinuxParser::Command(p_id); 
}

// TODO: Return this process's memory utilization
string Process::Ram() { 
    return ram; 
}

// TODO: Return the user (name) that generated this process
string Process::User() { 
    return user; 
}

// TODO: Return the age of this process (in seconds)
long int Process::UpTime() { 
    return up_time; 
}

// TODO: Overload the "less than" comparison operator for Process objects  
// REMOVE: [[maybe_unused]] once you define the function
bool Process::operator<(Process const& a) const {  
    return (a.cpu_>this->cpu_); 
}