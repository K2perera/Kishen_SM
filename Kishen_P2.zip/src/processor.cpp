#include <unistd.h>
#include <cctype>
#include <sstream>
#include <string>
#include <vector> 
#include "processor.h" 
#include "linux_parser.h" 
using namespace std; 

// TODO: Return the aggregate CPU utilization
float Processor::Utilization() {   
    string line,k,value; 
    std::ifstream file("/proc/stat");  
    std::getline(file,line); 
    std::istringstream linestream(line); 
    linestream >> k >> user >> nice >> system >> idle >> iowait >> irq >> softirq >> steal >> guest >> guest_nice; 

    int u_time = stoi(user) - stoi(guest); 
    int n_time = stoi(nice) - stoi(guest_nice); 
    int s_time = stoi(system) + stoi(irq) + stoi(softirq); 
    int i_time = stoi(idle) + stoi(iowait); 
    int v_time = stoi(guest_nice) + stoi(guest);  
    int s_teal = stoi(steal); 
    int total = u_time + n_time + s_time + i_time + v_time + s_teal; 

    return float((total - i_time)/(float)total);  
}