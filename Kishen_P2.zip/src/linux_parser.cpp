#include <algorithm>  
#include <dirent.h>
#include <unistd.h> 
#include <string> 
#include <iostream> 
#include <vector>   
#include "linux_parser.h" 
//using namespace std; 
using std::stof; 
using std::stol; 
using std::stoi; 
using std::string;
using std::to_string;
using std::vector;

// DONE: An example of how to read data from the filesystem
string LinuxParser::OperatingSystem() {
  string line;
  string key;
  string value;
  std::ifstream filestream(kOSPath);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::replace(line.begin(), line.end(), ' ', '_');
      std::replace(line.begin(), line.end(), '=', ' ');
      std::replace(line.begin(), line.end(), '"', ' ');
      std::istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "PRETTY_NAME") {
          std::replace(value.begin(), value.end(), '_', ' ');
          return value;
        }
      }
    }
  }
  return value;
}

// DONE: An example of how to read data from the filesystem
string LinuxParser::Kernel() {
  string os, kernel,model;
  string line;
  std::ifstream stream(kProcDirectory + kVersionFilename);
  if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> os >> kernel >>model;
  }
  return model;
}

// BONUS: Update this to use std::filesystem
vector<int> LinuxParser::Pids() {
  vector<int> pids;
  DIR* directory = opendir(kProcDirectory.c_str());
  struct dirent* file;
  while ((file = readdir(directory)) != nullptr) { 
    // Is this a directory?
    if (file->d_type == DT_DIR) {
      // Is every character of the name a digit?
      string filename(file->d_name); 
      if (std::all_of(filename.begin(),filename.end(),::isdigit)) {
        int pid = stoi(filename);
        pids.push_back(pid);
      }
    }
  }
  closedir(directory);
  return pids;
}

// TODO: Read and return the system memory utilization
float LinuxParser::MemoryUtilization() { 
  std::string line,k,value;
  float TotalMem; 
  float FreeMem; 
  std::ifstream fs (kProcDirectory+kMeminfoFilename); 
  
  if(fs.is_open()) {
    while(std::getline(fs,line)) { 
      std::istringstream linestream(line); 
      while(linestream >> k >> value) {
        if(k == "MemTotal") {
          TotalMem = stof(value); 
        } else if(k == "MemAvailable") {
          FreeMem = stof(value); 
        } 
      } 
    }
  }  
  return (TotalMem - FreeMem) / TotalMem; 
}

// TODO: Read and return the system uptime
long LinuxParser::UpTime() { 
   std::string line,idletime,ut;  
   std::ifstream f_s(kProcDirectory + kUptimeFilename); 
   if(f_s.is_open()) {
     std::getline(f_s,line); 
     std::istringstream l_s(line); 
     l_s >> ut >> idletime; 
   }  
   long uptime = stol(ut); 
   return uptime;  
}

long LinuxParser::Jiffies() { 
  return 0; 
}

// TODO: Read and return the number of active jiffies for a PID
// REMOVE: [[maybe_unused]] once you define the function
float LinuxParser::ActiveJiffies(int pid[[maybe_unused]]) { 
  return 0; 
}

long LinuxParser::ActiveJiffies() { 
  return 0; 
}

long LinuxParser::IdleJiffies() { 
  return 0; 
}

// TODO: Read and return CPU utilization
vector<string> LinuxParser::CpuUtilization() { 
  return {}; 
}

// TODO: Read and return the total number of processes
int LinuxParser::TotalProcesses() { 
  std::string line,k,value;  
  int pcs; 
  std::ifstream file(kProcDirectory+kStatFilename);
  if(file.is_open()) {
    while(std::getline(file, line)) {
      std::istringstream linestream(line); 
      while(linestream >> k >>value) {
        if(k == "processes") {
          pcs =stoi(value); 
        }
      }
    }
  }
  return pcs; 
}

// TODO: Read and return the number of running processes
int LinuxParser::RunningProcesses() {  
  std::string line,k,value; 
  int pcs;  
  std::ifstream file(kProcDirectory+kStatFilename);
  if(file.is_open()) {
    while(std::getline(file, line)) {
      std::istringstream linestream(line);  
      while(linestream>>k>>value) {
        if(k == "procs_running") {
          pcs = stoi(value); 
        }
      }
    } 
  }  
  return pcs; 
}

// TODO: Read and return the command associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Command(int pid) { 
  string line; 
  std::string PID = to_string(pid); 
  std::ifstream file(kProcDirectory+ PID + kCmdlineFilename); 
  if(file.is_open()) {
    std::getline(file, line); 
  }  
  return line; 
}

// TODO: Read and return the memory used by a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Ram(int pid) { 
  string line,k,value,ram;   
  std::string PID = to_string(pid); 
  std::ifstream file(kProcDirectory + PID + kStatusFilename);
  if(file.is_open()) {  
    while (std::getline(file, line)) {
      std::istringstream linestream(line); 
      while(linestream >> k >>value) {
        if(k == "VmSize") {
          ram = value; 
        } 
      }  
    }
  } 
  int x = stoi(value)/100; 
  string rambo = to_string(x);  
  return rambo; 
}

// TODO: Read and return the user ID associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Uid(int pid) { 
  string line,k,value,u_id; 
   std::string PID = to_string(pid); 
   std::ifstream file(kProcDirectory + PID + kStatusFilename);  
   if(file.is_open()) {  
    while (std::getline(file, line)) {
      std::istringstream linestream(line); 
      while(linestream >> k >>value) {
        if(k == "Uid") {
          u_id = value; 
        } 
      }  
    }
  }
  return u_id;  
}

// TODO: Read and return the user associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::User(int pid[[maybe_unused]]) { 
  string line,user;  
  string U_id =Uid(pid);  
  std::ifstream file(kPasswordPath);
  if(file.is_open()) {
    while (std::getline(file,line)) {
      std::istringstream linestream(line); 
      std::vector<std::string> t;  
      char sp_char =';';  
      for(std::string e;std::getline(linestream,e,sp_char);t.push_back(e)) {
        if(t[2] == U_id) {
          user = t[2]; 
        }
      }
    }
  } 
  return user;  
}

// TODO: Read and return the uptime of a process
// REMOVE: [[maybe_unused]] once you define the function
long LinuxParser::UpTime(int pid) { 
  string line,k,value,ram; 
  std::string PID = to_string(pid); 
  std::ifstream file (kProcDirectory + PID +kStatFilename);  
  std::getline(file,line);  
  std::istringstream linestream(line); 
  
  std::vector<std::string> results(std::istream_iterator<std::string>{linestream}, std::istream_iterator<std::string>()); 
  return (UpTime() - stol(results[21])/sysconf(_SC_CLK_TCK)); 
}