#ifndef PROCESSOR_H
#define PROCESSOR_H 
using std::string; 

class Processor {
 public:
  float Utilization();  // TODO: See src/processor.cpp

  // TODO: Declare any necessary private members 
 private:   
    string user;  
    string nice; 
    string system; 
    string idle; 
    string iowait; 
    string irq; 
    string softirq; 
    string steal; 
    string guest; 
    string guest_nice; 
};

#endif